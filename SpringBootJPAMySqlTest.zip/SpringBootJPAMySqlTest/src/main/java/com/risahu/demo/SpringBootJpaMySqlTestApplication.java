package com.risahu.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaMySqlTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaMySqlTestApplication.class, args);
	}

}
