package com.risahu.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.risahu.demo.model.Employee;


public interface EmployeeRepo extends JpaRepository <Employee, Long>{

}
