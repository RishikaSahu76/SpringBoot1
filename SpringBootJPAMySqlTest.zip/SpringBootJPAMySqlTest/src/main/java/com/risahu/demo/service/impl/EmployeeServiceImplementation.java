package com.risahu.demo.service.impl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.risahu.demo.exception.REsourceNotFoundException;
import com.risahu.demo.model.Employee;
import com.risahu.demo.repository.EmployeeRepo;
import com.risahu.demo.service.EmployeeService;

@Service
public class EmployeeServiceImplementation implements EmployeeService{

	public EmployeeRepo employeeRepository; 
	@Autowired
	public EmployeeServiceImplementation(EmployeeRepo employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}
	@Override
	public Employee saveEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeeRepository.save(emp);
	}
	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}
	@Override
	public Employee getEmployeeById(long id) {
		// TODO Auto-generated method stub
		Optional <Employee> employee = employeeRepository.findById(id);
		if(employee.isPresent())
			return employee.get();
		else
			throw new REsourceNotFoundException("Employee", "Id", id);
		// Lamba expression return employeeRepository.findId(id).orElseThrow(() -> new ResourceNotFoundException("Employee","Id",id);
		
	}
	@Override
	public Employee updateEmployee(Employee employee, long id) {
		// TODO Auto-generated method stub
		// check if given id is exist in database or not
		Employee existingEmployee = employeeRepository.findById(id).orElseThrow(() -> new REsourceNotFoundException("Employee", "Id", id));
		//if(existingEmployee.isPresent())
			existingEmployee.setFirstName(employee.getFirstName());
			existingEmployee.setLastName(employee.getLastName());
			existingEmployee.setEmail(employee.getEmail());
			//save existing employee to database
			employeeRepository.save(existingEmployee);
			
		
		return existingEmployee;
	}
	@Override
	public Employee deleteEmployee(long id) {
		//check whether an employee exist in database or not
		employeeRepository.findById(id).orElseThrow(() -> new REsourceNotFoundException("Employee", "Id", id));
		employeeRepository.deleteById(id);
		// TODO Auto-generated method stub
		return null;
	}
	

}
