package com.risahu.demo.service;

import com.risahu.demo.model.Employee;
import java.util.*;

public interface EmployeeService {
	Employee saveEmployee(Employee emp);
	List<Employee> getAllEmployees();
	Employee getEmployeeById(long id);
	Employee updateEmployee(Employee employee, long id);
	Employee deleteEmployee(long id);

}
