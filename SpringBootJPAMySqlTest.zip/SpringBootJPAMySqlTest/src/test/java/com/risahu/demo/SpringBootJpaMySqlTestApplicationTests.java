package com.risahu.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaMySqlTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
