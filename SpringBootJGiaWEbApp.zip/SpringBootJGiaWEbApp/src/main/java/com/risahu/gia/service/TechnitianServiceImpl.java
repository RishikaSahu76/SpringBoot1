package com.risahu.gia.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.risahu.gia.model.Technitian;
import com.risahu.gia.repository.TechnitianRepository;

@Service
@Transactional
public class TechnitianServiceImpl implements TechnitianService {
	@Autowired
	private TechnitianRepository technitianRepository;

	@Override
	public List<Technitian> getallTechnitian() {
		// TODO Auto-generated method stub
		return technitianRepository.findAll();
	}

	@Override
	public void saveTechnitian(Technitian technitian) {
		// TODO Auto-generated method stub
		this.technitianRepository.save(technitian);
		
	}

	@Override
	public Technitian getTechnitianById(long id) {
		// TODO Auto-generated method stub
		Optional<Technitian> optional = technitianRepository.findById(id);
		Technitian technitian = null;
		if(optional.isPresent()) {
			technitian = optional.get();
		}
		else {
			throw new RuntimeException("Technitian not found for id:"+id);
		}
		return technitian;
	}

	@Override
	public void deleteTechnitianById(long id) {
		// TODO Auto-generated method stub
		this.technitianRepository.deleteById(id);;
		
	}

	@Override
	public Page<Technitian> findPaginated(int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		Pageable pageable = PageRequest.of(pageNo -1, pageSize); //to start index from 1 page in springboot start with 0base
		return this.technitianRepository.findAll(pageable);
	}
	

}
