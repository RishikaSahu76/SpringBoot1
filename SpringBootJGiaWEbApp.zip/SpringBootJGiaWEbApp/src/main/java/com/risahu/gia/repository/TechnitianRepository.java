package com.risahu.gia.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.risahu.gia.model.Technitian;

public interface TechnitianRepository extends JpaRepository<Technitian, Long> {

}
