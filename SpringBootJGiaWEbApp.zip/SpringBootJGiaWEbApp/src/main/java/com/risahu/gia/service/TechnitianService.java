package com.risahu.gia.service;
import java.util.*;

import org.springframework.data.domain.Page;

import com.risahu.gia.model.Technitian;

public interface TechnitianService {
	List<Technitian> getallTechnitian();
	void saveTechnitian(Technitian technitian);
	Technitian getTechnitianById(long id);
	void deleteTechnitianById(long id);
	Page<Technitian> findPaginated(int pageNo, int pageSize);

}
