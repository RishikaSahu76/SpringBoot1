package com.risahu.gia.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.risahu.gia.model.User;
import com.risahu.gia.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);

}
