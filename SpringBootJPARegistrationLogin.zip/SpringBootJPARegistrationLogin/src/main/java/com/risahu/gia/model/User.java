package com.risahu.gia.model;
import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "user",uniqueConstraints = @UniqueConstraint(columnNames ="email"))
public class User {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private Long userId;
	
	@Column(name ="userfirstName")
	private String userfirstName;
	
	@Column(name ="userlastName")
	private String userlastName;
	private String email;
	private String password;
	@ManyToMany(fetch =FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name ="users_roles", joinColumns =@JoinColumn(name ="userauth_id",referencedColumnName ="userId"),
			inverseJoinColumns =@JoinColumn(name ="role_id",referencedColumnName ="userId"))
	private Collection<Role> roles;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserfirstName() {
		return userfirstName;
	}
	public void setUserfirstName(String userfirstName) {
		this.userfirstName = userfirstName;
	}
	public String getUserlastName() {
		return userlastName;
	}
	public void setUserlastName(String userlastName) {
		this.userlastName = userlastName;
	}
	
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Collection<Role> getRoles() {
		return roles;
	}
	public void setRoles(Collection<Role> roles) {
		this.roles = roles;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public User(String userfirstName, String userlastName, String password, String email, Collection<Role> roles) {
		super();
		this.userfirstName = userfirstName;
		this.userlastName = userlastName;
		this.password = password;
		this.email = email;
		this.roles = roles;
	}
	
	
	
	
	
}
