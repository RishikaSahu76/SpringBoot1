package com.risahu.gia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaRegistrationLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaRegistrationLoginApplication.class, args);
	}

}
